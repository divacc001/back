const express = require("express");
// const crypto = require('crypto');
const userRoute = require("./routes/userRoute");
const connectDb=require('./connectDb/connectDb')
var cors = require('cors') 
const app = express();
const dotenv = require("dotenv");
dotenv.config();
const port = process.env.PORT;
connectDb();
app.use(cors())
app.listen(port, (er) => {
  if (er) {
    console.log(er);
  } else {
    console.log(`server is running on port ${port}`);
  }
});
// const SECRET=crypto.randomBytes(256).toString('base64');
// console.log(SECRET)

app.use(express.json())
app.use("/api", userRoute);
app.use('/uploads', express.static('uploads'));

