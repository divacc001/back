const User = require("../models/User");
const jwt = require("jsonwebtoken");
require("dotenv").config();

// const getUsers = async (requset, response) => {
// try {
// const users = await User.find();
// response.status(200).json({ users: users });
// } catch (error) {
// response.status(500).json({ msg: "error on getting users" });
// }
// }
const getUsers = async (request, response) => {
  try { 
    const users = await User.find();
    if (users && users.length > 0) {
      response.status(200).json({ users: users });
    } else {
      response.status(404).json({ msg: "No users found" });
    }
  } catch (error) {
    console.error(error);
    response.status(500).json({ msg: "Error on getting users" });
  }
};


const getOneUser = async (req, res) => {
  const id = req.params.id;
  try {
    const foundUser = await User.findOne({ _id: id });
    if (foundUser) {
      res.status(200).json({ user: foundUser });
    } else {
      res.status(400).json({ msg: "no user found" });
    }
  } catch {
    res.status(500).json({ msg: "error on get one user users" });
  }
};

const postUser = async (request, response) => {
  const user = request.body;
  try {
    const foundUser = await User.findOne({ email: user.email });
    if (foundUser) {
      response.status(400).json({ msg: "user already exist" });
    } else {
      let newUser = new User(user);
      console.log(newUser);
      await newUser.save();
      response.status(200).json({ user: newUser, msg: "added sucess" });
    }
  } catch (error) {
    response.status(500).json({ msg: "error on adding user" });
  }
};

const postUserwithImage = async (req, res) => {
  try {
    // Access the uploaded file via req.file
    const file = req.file;

    // Assuming the text fields (userName, email, age) are sent as part of the form data
    const { userName, email, password } = req.body;

    if (!file) {
      return res.status(400).send("No file uploaded.");
    }

    // Create a new user instance with both the file details and text data
    const newUser = new User({
      userName: userName,
      email: email,
      password: password,
      profileImagePath: file.path, // Save the path of the uploaded file
    });

    // Save the user to the database
    await newUser.save();

    // Send back the newly created user data
    res.status(201).json(newUser);
  } catch (error) {
    console.error("Error details:", error);
    return res.status(500).send("Server error while creating user: " + error.message);
  }
  
};

const putUser = async (req, res) => {
  const id = req.params.id;
  const user = req.body;
  console.log(user);
  try {
    await User.findByIdAndUpdate(id, user);
    res.status(200).json({ msg: "update sucess" });
  } catch (error) {
    res.status(500).json({ msg: "error on update user" });
  }
};
const deleteUser = async (req, res) => {
  const id = req.params.id;
  try {
    await User.findByIdAndDelete(id);
    res.status(200).json({ msg: "delete done" });
  } catch (error) {
    res.status(500).json({ msg: "error on deleting user" });
  }
};


const postUserProfile = async (req, res) => {
  try {
    // Access the uploaded file via req.file
    const file = req.file;

    // Access the user ID from the URL parameter
    const userId = req.params.id;

    if (!file) {
      return res.status(400).send("No file uploaded.");
    }

    // Assuming you have a User model and want to store the file info
    // You might want to update the user's profile with the file details
    // This could vary greatly depending on how your database and models are set up
    const updatedUser = await User.findByIdAndUpdate(
      userId,
      { profileImagePath: file.path }, // Example: updating the path of the profile image
      { new: true } // Return the updated user object
    );

    if (!updatedUser) {
      return res.status(404).send("User not found.");
    }

    // Send back some information, maybe the updated user data
    res.json(updatedUser);
  } catch (error) {
    console.error(error);
    res.status(500).send("Server error while uploading file.");
  }
};

const signIn = async (req, res) => {
  const user = req.body;
  try {
    const foundUser = await User.findOne({ email: user.email });

    if (foundUser) {
      if (user.password === foundUser.password) {
        // Note: Consider using hashed passwords in production
        const token = jwt.sign(
          { id: foundUser._id, role: foundUser.role },
          process.env.JWT_SECRET
        );
        res.status(200).json({ user: foundUser, token: token });
      } else {
        res.status(400).json({ msg: "Wrong password" });
      }
    } else {
      return res.status(400).json({ msg: "User not registered" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ msg: "Server error" });
  }
};

module.exports = {
  postUserwithImage,
  getUsers,
  postUser,
  putUser,
  deleteUser,
  getOneUser,
  postUserProfile,
  signIn,
};
