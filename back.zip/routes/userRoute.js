const express = require("express");
const upload = require('../multerConfig'); 
const userRoute = express.Router();
const {
getUsers,
postUser,
putUser,
deleteUser,
getOneUser,
postUserProfile,postUserwithImage,signIn,
} = require("../Controllers/userController");
const isAuth = require("../middleware/isAuth")
const isAutho=require('../middleware/isAutho')
userRoute.get("/users", getUsers);
userRoute.get("/users/:id", isAuth,isAutho(['user']), getOneUser);

userRoute.post("/users", postUser);
userRoute.post("/users/uploads", upload.single('file'), postUserwithImage);
userRoute.put("/users/:id", putUser);

userRoute.delete("/users/:id",isAuth,isAutho(['admin']), deleteUser);

userRoute.post("/users/:id/uploads", upload.single('file'), postUserProfile);

userRoute.post("/signIn", signIn);


module.exports = userRoute;
